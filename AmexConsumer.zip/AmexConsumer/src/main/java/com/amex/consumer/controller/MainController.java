package com.amex.consumer.controller;

import com.amex.consumer.EventRepository;
import com.amex.consumer.model.Events;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author CraigWorsell
 */
@RestController
@RequestMapping("amex/api")
public class MainController {
    
    private final static Log LOG = LogFactory.getLog(MainController.class);
    
    @Autowired
    private EventRepository repository;
    
    /**
     * Request for checking the api status
     * @return 
     */
    @RequestMapping(method=RequestMethod.GET)
    public ResponseEntity<String> getStatus() {
        return new ResponseEntity<>("{\"status\":\"Running\"}", HttpStatus.OK);
    }
    
    /**
     * POST request to save to the repository, accepts JSON
     * representation of the Events object
     * 
     * @param events
     * @return The Saved Events object
     * @throws Exception 
     */
    @RequestMapping(value="events", method=RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<Events> putEvent(@RequestBody Events events) throws Exception {
        LOG.info("New POST request received");
        repository.save(events);
        LOG.info(events.toString() + " saved to repository");
        return new ResponseEntity<>(events, HttpStatus.OK);
    }
    
    
    /**
     * GET request to get all persisted Events
     * 
     * @return 
     */
    @RequestMapping(value="events", method=RequestMethod.GET)
    @ResponseBody
    public List<Events> getEvents() {
        return repository.findAll();
    }
}
