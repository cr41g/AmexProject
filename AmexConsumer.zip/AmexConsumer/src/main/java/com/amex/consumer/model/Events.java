package com.amex.consumer.model;

import org.springframework.data.annotation.Id;

/**
 *
 * @author CraigWorsell
 */
public class Events {
    @Id
    public String id;
    
    private long accountNumber;
    private String transactionAmount;
    private String name;
    private String product;
    
    public Events() {}

    public Events(long accountNumber, String transactionAmount, String name, String product) {
        this.accountNumber = accountNumber;
        this.transactionAmount = transactionAmount;
        this.name = name;
        this.product = product;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(long accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(String transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }
    
    @Override
    public String toString() {
        return "{accountNumber:" + accountNumber + ", transactionAmount:'" + transactionAmount + "', name:'" + name + "', product:'" + product + "'}";
    }
}
