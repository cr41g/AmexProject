package com.amex.consumer;

import com.amex.consumer.model.Events;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 *
 * @author CraigWorsell
 */
public interface EventRepository extends MongoRepository<Events, String> {
    /* The Spring framework produces all the CRUD operations, so there is no need for any methods
       unless more specific queries are required. Not in this case.
    */
}
