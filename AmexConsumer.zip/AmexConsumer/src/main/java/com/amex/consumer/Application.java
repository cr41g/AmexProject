package com.amex.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *
 * @author CraigWorsell
 */
@SpringBootApplication
public class Application {
    
    public static void main(String[] args) {
        /* Use Spring Boot to run the application */
        SpringApplication.run(Application.class, args);
    }
}
