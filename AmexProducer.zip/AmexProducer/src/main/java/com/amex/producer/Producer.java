package com.amex.producer;

import com.amex.producer.model.Event;
import com.amex.producer.model.Events;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
/**
 *
 * @author CraigWorsell
 */
public class Producer {
    
    private final static Log LOG = LogFactory.getLog(Producer.class);
    private final ObjectMapper mapper = new ObjectMapper();
    private final Properties props = new Properties();
    
    public static void main(String[] args) throws URISyntaxException, IOException {
        Producer producer = new Producer();
        List<Event> events = producer.getSourceData();
        events.stream().forEach((event) -> {
            producer.sendToConsumer(event);
        });
    }
    
    public Producer() {
        /* Load properties */
        try {
            props.load(Producer.class.getClassLoader().getResourceAsStream("application.properties"));
        } catch (IOException e) {
            LOG.error("Could not load properties");
            LOG.error(e.getMessage());
        }
    }
    
    public List<Event> getSourceData() throws URISyntaxException, IOException {
        URL resource = Producer.class.getClassLoader().getResource("source.txt");
        File src = Paths.get(resource.toURI()).toFile();
        /* Read content from file and split on new line */
        String content = new String(Files.readAllBytes(Paths.get(src.getAbsolutePath())));
        String[] lines = content.split("\n");
        /* Create object from JSON and add to list */
        List<Event> eventsList = new ArrayList<>();
        for (String line:lines) {
            Events events = mapper.readValue(line, Events.class);
            LOG.info(events.getEvents().toString());
            eventsList.add(events.getEvents().get(0));
        }
        return eventsList;
    }
    
    private void sendToConsumer(Event event) {
        /* Consumer service only requires the attributes */
        String json = event.getAttributes().toString();
        LOG.info("Sending " + json + " to consumer");        
        HttpURLConnection connection = null;
        String result = "";
        /* Http Put connection to the consumer */
        try {
            URL url = new URL(props.getProperty("consumer.url"));
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("accept", "application/json");
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setDoInput(true);
            OutputStream out = connection.getOutputStream();
            out.write(event.getAttributes().toString().getBytes());
            if (connection.getResponseCode() != 200) {
                result = "Could not save " + json;
            } else {
                InputStream in = connection.getInputStream();
                String inStr;
                /* Consumer service returns the saved object as JSON */
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
                    while ((inStr = reader.readLine()) != null)
                        result = inStr;
                } catch (Exception e) {
                    result = "Could not get result JSON";
                }
            }
            LOG.info(result);
        } catch (IOException e) {
            LOG.error("Could not send to consumer");
            LOG.error(e.getMessage());
        } finally {         
            if (connection != null) {
                connection.disconnect();
            }
        }
        LOG.info("Finished sending " + event.toString() + " to consumer");
    }
}