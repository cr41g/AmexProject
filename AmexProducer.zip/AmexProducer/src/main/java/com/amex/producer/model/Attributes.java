package com.amex.producer.model;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 *
 * @author CraigWorsell
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonPropertyOrder({
"Account Number",
"Transaction Amount",
"Name",
"Product"
})
public class Attributes {

    @JsonProperty("Account Number")
    private String accountNumber;
    @JsonProperty("Transaction Amount")
    private String transactionAmount;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Product")
    private String product;

    @JsonProperty("Account Number")
    public String getAccountNumber() {
        return accountNumber;
    }

    @JsonProperty("Account Number")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    @JsonProperty("Transaction Amount")
    public String getTransactionAmount() {
        return transactionAmount;
    }

    @JsonProperty("Transaction Amount")
    public void setTransactionAmount(String transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("Product")
    public String getProduct() {
        return product;
    }

    @JsonProperty("Product")
    public void setProduct(String product) {
        this.product = product;
    }

    @Override
    public String toString() {
        return "{\"accountNumber\":" + accountNumber + ", \"transactionAmount\":\"" + transactionAmount + 
                "\", \"name\":\"" + name + "\", \"product\":\"" + product + "\"}";
    }
}
