package com.amex.producer;

import com.amex.producer.model.Event;
import java.util.List;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

/**
 *
 * @author CraigWorsell
 */
public class ProducerTest {
    
    private final Producer producer = new Producer();

    @Test
    public void getSourceDataSuccess_Test() throws Exception {        
        List<Event> list = producer.getSourceData();
        assertNotNull(list);
        assertTrue("List should not be empty", list.size() > 0);
    }
}
